from fastapi import FastAPI
from mangum import Mangum
from app.api.main import api_router

app = FastAPI()

# Include your router here
app.include_router(api_router)

# Define your root endpoint
@app.get("/")
def root():
    return {"message": "Api 1.0"}

# Create the Mangum handler after all routes are defined
handler = Mangum(app)
